package com.example.final_uygulama

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
